const users = [{
  id: 1,
  firstName: 'FirstName 1'
}, {
  id: 2,
  firstName: 'FirstName 2'
}, {
  id: 3,
  firstName: 'FirstName 3'
}];

module.exports = users;