console.log(__projectdir + '/file.txt');
