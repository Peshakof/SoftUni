const cubeModel = require('./cube');
const accessoryModel = require('./accessories');

module.exports = { cubeModel, accessoryModel };