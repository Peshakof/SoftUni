module.exports = {
  myFunc2: function () {

  }
}