module.exports = {
  myFunc1: function () { }
}