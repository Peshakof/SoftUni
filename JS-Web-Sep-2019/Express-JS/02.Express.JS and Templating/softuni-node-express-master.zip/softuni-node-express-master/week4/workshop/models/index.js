const cubeModel = require('./cube');
const accessoryModel = require('./accessories');
const userModel = require('./user');
const tokenBlacklistModel = require('./token-blacklist');

module.exports = { cubeModel, accessoryModel, userModel, tokenBlacklistModel };