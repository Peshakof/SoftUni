const authCookieName = 'auth_cookie';

module.exports = {
  authCookieName
};
